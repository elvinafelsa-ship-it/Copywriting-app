# Aplikasi Copywriting Sederhana

Dibuat dengan **HTML + Tailwind CSS** oleh Vina Creative.

## Cara Jalankan

1. Buka file `index.html` di browser lokal Anda.
2. Atau host di GitHub Pages:
   - Buat repo baru di GitHub (misalnya `copywriter-app`).
   - Upload file `index.html` dan `README.md` ke repo.
   - Masuk ke Settings → Pages → pilih branch `main` dan folder `/root`.
   - Aplikasi bisa diakses di `https://username.github.io/copywriter-app/`.

## Fitur
- Input nama produk, audiens, fitur/benefit
- Pilih tone & panjang copywriting
- Generate 3 variasi copywriting otomatis
- Tombol Copy untuk salin hasil
- Tombol Copy All untuk salin semua hasil sekaligus
